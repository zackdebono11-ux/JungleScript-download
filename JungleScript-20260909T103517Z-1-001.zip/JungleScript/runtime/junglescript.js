// ==========================================
// 🌴 JUNGLESCRIPT RUNTIME v0.5
// ==========================================

class JungleScriptRuntime {

    constructor(assets = {}) {

        this.modules = new Set();
        this.assets = assets;
        this.currentAudio = null;
        this.variables = {};
        this.gameRuntime = null;

    }


    // ==========================================
    // ▶ RUN PROGRAM
    // ==========================================

    run(code) {

        const lines = code.split("\n");

        let i = 0;

        while (i < lines.length) {

            const line = lines[i].trim();

            if (line === "") {
                i++;
                continue;
            }


            // ==========================================
            // 🔀 IF BLOCK
            // ==========================================

            if (line.startsWith("if ")) {

                const condition =
                    line.substring(3).trim();

                const blockLines = [];

                let depth = 1;

                i++;

                while (i < lines.length && depth > 0) {

                    const blockLine =
                        lines[i].trim();

                    if (blockLine.startsWith("if ")) {
                        depth++;
                    }

                    if (blockLine === "end") {
                        depth--;
                    }

                    if (depth > 0) {
                        blockLines.push(lines[i]);
                    }

                    i++;

                }


                // Missing end

                if (depth !== 0) {

                    this.error(
                        i,
                        'Missing "end" for if statement.'
                    );

                    continue;

                }


                const result =
                    this.evaluateCondition(condition);


                if (result) {

                    this.run(
                        blockLines.join("\n")
                    );

                }

                continue;

            }


            // ==========================================
            // ❌ UNEXPECTED END
            // ==========================================

            if (line === "end") {

                this.error(
                    i + 1,
                    '"end" does not have a matching "if".'
                );

                i++;

                continue;

            }


            // ==========================================
            // ▶ NORMAL COMMAND
            // ==========================================

            this.executeLine(
                line,
                i + 1
            );

            i++;

        }

    }


    // ==========================================
    // 🧠 EVALUATE CONDITION
    // ==========================================

    evaluateCondition(condition) {

        // Replace variables with their values

        for (const name in this.variables) {

            const value =
                this.variables[name];

            const regex =
                new RegExp(
                    `\\b${name}\\b`,
                    "g"
                );

            condition =
                condition.replace(
                    regex,
                    JSON.stringify(value)
                );

        }


        // ==========================================
        // 📝 STRING COMPARISON
        // ==========================================

        const stringMatch =
            condition.match(
                /^"(.+)"\s(==|!=)\s"(.+)"$/
            );

        if (stringMatch) {

            const left =
                stringMatch[1];

            const operator =
                stringMatch[2];

            const right =
                stringMatch[3];


            if (operator === "==") {
                return left === right;
            }

            if (operator === "!=") {
                return left !== right;
            }

        }


        // ==========================================
        // 🔢 NUMBER COMPARISON
        // ==========================================

        const numberMatch =
            condition.match(
                /^(-?\d+(?:\.\d+)?)\s(==|!=|>=|<=|>|<)\s(-?\d+(?:\.\d+)?)$/
            );

        if (numberMatch) {

            const left =
                Number(numberMatch[1]);

            const operator =
                numberMatch[2];

            const right =
                Number(numberMatch[3]);


            switch (operator) {

                case "==":
                    return left === right;

                case "!=":
                    return left !== right;

                case ">":
                    return left > right;

                case "<":
                    return left < right;

                case ">=":
                    return left >= right;

                case "<=":
                    return left <= right;

            }

        }


        console.warn(
            `Could not evaluate condition: ${condition}`
        );

        return false;

    }


    // ==========================================
    // 🧩 EXECUTE LINE
    // ==========================================

    executeLine(line, lineNumber) {


        // ==========================================
        // 📦 VARIABLES
        // ==========================================

        const variableMatch =
            line.match(
                /^([a-zA-Z_][a-zA-Z0-9_])\s=\s(.+)$/
            );

        if (variableMatch) {

            const variableName =
                variableMatch[1];

            const value =
                variableMatch[2].trim();


            // ==========================================
            // 🎲 RANDOM
            // ==========================================

            if (value === "random") {

                const randomNumber =
                    Math.floor(
                        Math.random() * 100
                    ) + 1;

                this.variables[variableName] =
                    randomNumber;

                console.log(
                    `🎲 ${variableName} = ${randomNumber}`
                );

                return;
                

            }
           



            // ==========================================
            // 🔢 NUMBER
            // ==========================================

            if (
                /^-?\d+(?:\.\d+)?$/.test(value)
            ) {

                this.variables[variableName] =
                    Number(value);

                console.log(
                    `📦 ${variableName} = ${value}`
                );

                return;

            }


            // ==========================================
            // 📝 STRING
            // ==========================================

            const stringValue =
                value.match(/^"(.+)"$/);

            if (stringValue) {

                this.variables[variableName] =
                    stringValue[1];

                console.log(
                    `📦 ${variableName} = "${stringValue[1]}"`
                );

                return;

            }


            this.error(
                lineNumber,
                `Could not understand value "${value}".`
            );

            return;

        }


        // ==========================================
        // 📄 file_name()
        // ==========================================

        const fileNameMatch =
            line.match(/^file_name\("(.+)"\)$/);

        if (fileNameMatch) {

            console.log(
                `📄 JungleScript file: ${fileNameMatch[1]}`
            );

            return;

        }


        // ==========================================
        // 🌴 use()
        // ==========================================

        const useMatch =
            line.match(/^use\("(.+)"\)$/);

        if (useMatch) {

            const moduleName =
                useMatch[1];

            this.modules.add(moduleName);

            console.log(
                `🌴 Loaded module: ${moduleName}`
            );
            


            // ==========================================
            // 🎮 CONNECT JUNGLEGAME
            // ==========================================

            if (
                moduleName === "JungleGame" &&
                typeof JungleGameRuntime !== "undefined"
            ) {

                const preview =
                    document.getElementById("previewOutput");

                this.gameRuntime =
                    new JungleGameRuntime(preview);

                console.log(
                    "🎮 JungleGame engine connected!"
                );

            }

            return;

        }


        // ==========================================
        // 🌐 page()
        // ==========================================

        const pageMatch =
            line.match(/^page\("(.+)"\)$/);

        if (pageMatch) {

            if (!this.modules.has("JungleWeb")) {

                this.error(
                    lineNumber,
                    "JungleWeb must be loaded before using page()"
                );

                return;

            }

            document.title =
                pageMatch[1];

            console.log(
                `🌐 Page: ${pageMatch[1]}`
            );

            return;

        }


        // ==========================================
        // 📝 heading()
        // ==========================================

        const headingMatch =
            line.match(/^heading\("(.+)"\)$/);

        if (headingMatch) {

            if (!this.modules.has("JungleWeb")) {

                this.error(
                    lineNumber,
                    "JungleWeb must be loaded before using heading()"
                );

                return;

            }

            const heading =
                document.createElement("h1");

            heading.textContent =
                headingMatch[1];

            document
                .getElementById("previewOutput")
                .appendChild(heading);

            return;

        }


        // ==========================================
        // 📃 text()
        // ==========================================

        const textMatch =
            line.match(/^text\("(.+)"\)$/);

        if (textMatch) {

            if (!this.modules.has("JungleWeb")) {

                this.error(
                    lineNumber,
                    "JungleWeb must be loaded before using text()"
                );

                return;

            }

            const paragraph =
                document.createElement("p");

            paragraph.textContent =
                textMatch[1];

            document
                .getElementById("previewOutput")
                .appendChild(paragraph);

            return;

        }


        // ==========================================
        // 🔘 button()
        // ==========================================

        const buttonMatch =
            line.match(/^button\("(.+)"\)$/);

        if (buttonMatch) {

            if (!this.modules.has("JungleWeb")) {

                this.error(
                    lineNumber,
                    "JungleWeb must be loaded before using button()"
                );

                return;

            }

            const webButton =
                document.createElement("button");

            webButton.textContent =
                buttonMatch[1];

            webButton.style.padding =
                "10px 16px";

            webButton.style.margin =
                "8px 0";

            webButton.style.cursor =
                "pointer";

            webButton.addEventListener(
                "click",
                () => {

                    console.log(
                        `🖱️ Button "${buttonMatch[1]}" clicked!`
                    );

                }
            );

            document
                .getElementById("previewOutput")
                .appendChild(webButton);

            return;

        }


        // ==========================================
        // 📦 grabAsset()
        // ==========================================

        const grabAssetMatch =
            line.match(/^grabAsset\("(.+)"\)$/);

        if (grabAssetMatch) {

            const filename =
                grabAssetMatch[1];

            if (!this.assets[filename]) {

                this.error(
                    lineNumber,
                    `Asset "${filename}" was not found.`
                );

                return;

            }

            console.log(
                `📦 Grabbed asset: ${filename}`
            );

            return;

        }


        // ==========================================
        // ▶ playAsset()
        // ==========================================

        const playAssetMatch =
            line.match(/^playAsset\("(.+)"\)$/);

        if (playAssetMatch) {

            const filename =
                playAssetMatch[1];

            const file =
                this.assets[filename];

            if (!file) {

                this.error(
                    lineNumber,
                    `Asset "${filename}" was not found.`
                );

                return;

            }

            if (!file.type.startsWith("audio/")) {

                this.error(
                    lineNumber,
                    `"${filename}" is not an audio asset.`
                );

                return;

            }


            if (this.currentAudio) {

                this.currentAudio.pause();

                this.currentAudio.currentTime = 0;

                this.currentAudio = null;

            }


            const audioURL =
                URL.createObjectURL(file);

            this.currentAudio =
                new Audio(audioURL);

            this.currentAudio.volume = 1.0;


            this.currentAudio
                .play()
                .then(() => {

                    console.log(
                        `🎵 Playing asset: ${filename}`
                    );

                })
                .catch(error => {

                    this.error(
                        lineNumber,
                        `Could not play "${filename}": ${error.message}`
                    );

                });

            return;

        }


        // ==========================================
        // ⏹ stopAsset()
        // ==========================================

        const stopAssetMatch =
            line.match(/^stopAsset\("(.+)"\)$/);

        if (stopAssetMatch) {

            const filename =
                stopAssetMatch[1];


            if (this.currentAudio) {

                this.currentAudio.pause();

                this.currentAudio.currentTime = 0;

                this.currentAudio = null;

                console.log(
                    `⏹️ Stopped asset: ${filename}`
                );

            } else {

                console.log(
                    "⏹️ No audio is currently playing."
                );

            }

            return;

        }
        // ==========================================
// 🤖 AI CREATE GAME
// ==========================================

// ==========================================
// 🤖 AI CREATE GAME
// ==========================================

if (line.startsWith("aiCreateGame(")) {

    const match = line.match(
        /^aiCreateGame\(["'](.*)["']\)$/
    );

    if (!match) {
        this.error(
            lineNumber,
            "Invalid aiCreateGame() syntax."
        );
        return;
    }

    const prompt = match[1];

    if (
        this.gameRuntime &&
        typeof this.gameRuntime.aiCreateGame === "function"
    ) {

        this.gameRuntime.aiCreateGame(prompt);

        console.log(
            "🤖 AI game generation started!"
        );

    } else {

        this.error(
            lineNumber,
            'JungleGame is not loaded. Use use("JungleGame") first.'
        );
        
    }

    return;
}
        // ==========================================
// 🧊 3D()
// ==========================================

if (line === "3D()") {

    if (
        this.modules.has("3D") &&
        typeof Jungle3D !== "undefined"
    ) {

        this.game3D =
            new Jungle3D(
                document.getElementById("previewOutput")
            );

        this.game3D.start();

        console.log(
            "🧊 Jungle 3D mode started!"
        );

    } else {

        console.error(
            '❌ 3D engine not loaded. Use use("3D") first.'
        );

    }

    return;
}


        // ==========================================
        // 🎮 JUNGLEGAME COMMANDS
        // ==========================================

        if (
            this.modules.has("JungleGame") &&
            this.gameRuntime
        ) {

            const handled =
                this.gameRuntime.execute(line);

            if (handled) {
                return;
            }

        }


        // ==========================================
        // ❌ UNKNOWN COMMAND
        // ==========================================

        this.error(
            lineNumber,
            `Unknown command: ${line}`
        );

    }


    // ==========================================
    // ❌ ERROR
    // ==========================================

    error(lineNumber, message) {

        console.error(
            `JungleScript Error on line ${lineNumber}: ${message}`
        );

    }

}